// Background service worker
// Atualmente vazio, mas necessário para futuras expansões e persistência no MV3
console.log("Extensão de Tradução Edge carregada.");
